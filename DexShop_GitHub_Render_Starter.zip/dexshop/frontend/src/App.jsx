import React, { useMemo, useState } from "react";
import { Search, ShoppingCart, UserRound, Menu, Truck, ShieldCheck, Headphones, Gift, Star, Heart, ChevronDown, Zap, X, Plus, Minus, PackageCheck } from "lucide-react";

const products = [
  {id:1,name:"Écouteurs Bluetooth sans fil",category:"Téléphones & Accessoires",price:1250,old:2500,rating:4.8,discount:50,emoji:"🎧",color:"#f1f3f7"},
  {id:2,name:"Smartphone Android 128GB",category:"Téléphones & Accessoires",price:9999,old:16500,rating:4.7,discount:40,emoji:"📱",color:"#ece8ff"},
  {id:3,name:"Montre intelligente sport",category:"Électronique",price:1800,old:4500,rating:4.7,discount:60,emoji:"⌚",color:"#e8edf2"},
  {id:4,name:"Enceinte Bluetooth portable",category:"Électronique",price:2200,old:4000,rating:4.8,discount:45,emoji:"🔊",color:"#e6eef5"},
  {id:5,name:"Baskets modernes unisexes",category:"Chaussures",price:2800,old:4300,rating:4.6,discount:35,emoji:"👟",color:"#f0eee9"},
  {id:6,name:"Friteuse à air multifonction",category:"Maison & Jardin",price:4500,old:9999,rating:4.7,discount:55,emoji:"🍟",color:"#f3e8df"},
  {id:7,name:"Sac à main tendance",category:"Mode & Vêtements",price:1900,old:3200,rating:4.5,discount:40,emoji:"👜",color:"#f5e6e9"},
  {id:8,name:"Lunettes de soleil",category:"Mode & Vêtements",price:850,old:1500,rating:4.6,discount:43,emoji:"🕶️",color:"#e8e9ed"},
  {id:9,name:"Clavier sans fil",category:"Ordinateurs & Bureau",price:2100,old:3500,rating:4.7,discount:40,emoji:"⌨️",color:"#e8edf2"},
  {id:10,name:"Ballon de football",category:"Sports & Loisirs",price:1200,old:2000,rating:4.8,discount:40,emoji:"⚽",color:"#e8f0e7"},
  {id:11,name:"Kit de soins beauté",category:"Beauté & Santé",price:1600,old:2800,rating:4.5,discount:43,emoji:"🧴",color:"#f5e9ee"},
  {id:12,name:"Voiture télécommandée",category:"Jouets & Jeux",price:2400,old:3900,rating:4.6,discount:38,emoji:"🏎️",color:"#f5e9e4"}
];
const categories = ["Toutes les catégories","Téléphones & Accessoires","Ordinateurs & Bureau","Électronique","Mode & Vêtements","Chaussures","Maison & Jardin","Beauté & Santé","Sports & Loisirs","Jouets & Jeux","Auto & Moto"];
const money = n => new Intl.NumberFormat("fr-FR").format(n) + " HTG";

function App() {
  const [query,setQuery] = useState("");
  const [category,setCategory] = useState(categories[0]);
  const [cart,setCart] = useState([]);
  const [cartOpen,setCartOpen] = useState(false);
  const [notice,setNotice] = useState("");
  const [sort,setSort] = useState("popular");
  const [mobileMenu,setMobileMenu] = useState(false);
  const [checkout,setCheckout] = useState(false);
  const [customer,setCustomer] = useState({name:"",phone:"",address:"",email:""});
  const filtered = useMemo(() => products.filter(p => (category===categories[0] || p.category===category) && p.name.toLowerCase().includes(query.toLowerCase())).sort((a,b)=>sort==="price" ? a.price-b.price : sort==="discount" ? b.discount-a.discount : b.rating-a.rating),[query,category,sort]);
  const count = cart.reduce((s,p)=>s+p.qty,0);
  const total = cart.reduce((s,p)=>s+p.price*p.qty,0);
  const add = p => { setCart(old => { const found=old.find(x=>x.id===p.id); return found ? old.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x) : [...old,{...p,qty:1}]; }); setNotice("Produit ajouté au panier !"); setTimeout(()=>setNotice(""),2200); };
  const changeQty = (id,delta) => setCart(old=>old.map(p=>p.id===id?{...p,qty:p.qty+delta}:p).filter(p=>p.qty>0));
  const submitOrder = async e => {
    e.preventDefault();
    try {
      const res = await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customer,items:cart,total})});
      if(!res.ok) throw new Error("api");
      setNotice("Commande enregistrée ! Nous vous contacterons pour confirmer le paiement.");
      setCart([]); setCheckout(false); setCartOpen(false);
    } catch { setNotice("Le serveur de commande n'est pas encore configuré. Réessayez après le déploiement du backend."); }
    setTimeout(()=>setNotice(""),5000);
  };

  return <div className="app">
    <div className="topbar"><span>✈ Livraison dans le monde entier</span><span><ShieldCheck size={15}/> Achats sécurisés</span><span><Headphones size={15}/> Assistance 24/7</span><div className="topright">Bienvenue sur DexShop !　🇭🇹　HTG</div></div>
    <header className="header">
      <button className="mobile-toggle" onClick={()=>setMobileMenu(!mobileMenu)}><Menu/></button>
      <a className="brand" href="#"><span className="brandmark">D</span><span><b>Dex<span>Shop</span></b><small>Achetez Plus, Payez Moins !</small></span></a>
      <div className="search"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Rechercher un produit..."/><button aria-label="Rechercher"><Search/></button></div>
      <button className="account"><UserRound/><span>Mon compte</span></button>
      <button className="cart-button" onClick={()=>setCartOpen(true)}><ShoppingCart/><span>Mon panier</span><b>{count}</b></button>
    </header>
    <nav className="nav"><button className="allcats" onClick={()=>setMobileMenu(!mobileMenu)}><Menu size={19}/> Toutes les catégories <ChevronDown size={15}/></button><a className="active" href="#">⌂　Accueil</a><a href="#products">♨　Promotions</a><a href="#products">★　Meilleures ventes</a><a href="#products">◆　Nouveautés</a><a href="#benefits">♧　Nos services</a></nav>
    <main>
      <section className="hero">
        <div className="hero-copy"><span className="eyebrow">LA GRANDE BOUTIQUE EN LIGNE</span><h1>Achetez Plus,<br/><em>Payez Moins !</em></h1><p>Découvrez des milliers de produits à petits prix.</p><a href="#products" className="white-btn">Acheter maintenant　→</a><div className="hero-tags"><span>✓ Bons prix</span><span>✓ Grand choix</span><span>✓ Service client</span></div></div>
        <div className="hero-art"><div className="orb orb1"></div><div className="orb orb2"></div><div className="hero-emoji">📱 🎧 ⌚ 👟</div><div className="sale-sticker">JUSQU'À<br/><strong>-70%</strong></div></div>
      </section>
      <section className="benefits" id="benefits"><div><Truck/><span><b>Livraison mondiale</b><small>Suivi de commande</small></span></div><div><ShieldCheck/><span><b>Paiement sécurisé</b><small>Achats en confiance</small></span></div><div><Headphones/><span><b>Assistance 24/7</b><small>À votre écoute</small></span></div><div><Gift/><span><b>Offres exclusives</b><small>Économisez davantage</small></span></div></section>
      <section className="shop" id="products">
        <aside className={`sidebar ${mobileMenu?"show":""}`}><h3>Catégories</h3>{categories.map((c,i)=><button key={c} className={category===c?"selected":""} onClick={()=>{setCategory(c);setMobileMenu(false)}}><span>{["▦","📱","💻","🔌","👕","👟","🏠","🧴","⚽","🧸","🚗"][i]}</span>{c}</button>)}</aside>
        <div className="products-area"><div className="section-heading"><div><span className="flame">♨</span><h2>Produits populaires</h2><p>{filtered.length} produits à découvrir</p></div><select value={sort} onChange={e=>setSort(e.target.value)}><option value="popular">Les plus populaires</option><option value="price">Prix : croissant</option><option value="discount">Meilleures réductions</option></select></div>
          <div className="product-grid">{filtered.map(p=><article className="product" key={p.id}><div className="product-picture" style={{background:p.color}}><span className="discount">-{p.discount}%</span><button className="heart" onClick={()=>setNotice("Ajoutez vos favoris après connexion.")}><Heart size={18}/></button><span className="product-emoji">{p.emoji}</span></div><div className="product-info"><small>{p.category}</small><h3>{p.name}</h3><div className="rating"><span>★★★★★</span> {p.rating}</div><div className="prices"><b>{money(p.price)}</b><del>{money(p.old)}</del></div><button className="add" onClick={()=>add(p)}><ShoppingCart size={16}/> Ajouter au panier</button></div></article>)}</div>
          {filtered.length===0&&<div className="empty">Aucun produit trouvé. Essayez une autre recherche.</div>}
        </div>
      </section>
    </main>
    <footer><a className="brand footerbrand" href="#"><span className="brandmark">D</span><span><b>Dex<span>Shop</span></b><small>Achetez Plus, Payez Moins !</small></span></a><p>Votre boutique en ligne à portée de main.</p><small>© 2026 DexShop. Tous droits réservés.</small></footer>
    {notice&&<div className="toast">{notice}</div>}
    {cartOpen&&<div className="overlay" onClick={()=>setCartOpen(false)}><div className="drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><h2>Mon panier ({count})</h2><button onClick={()=>setCartOpen(false)}><X/></button></div>{cart.length===0?<div className="empty">Votre panier est vide 🛒</div>:<><div className="cart-items">{cart.map(p=><div className="cart-item" key={p.id}><span className="cart-emoji">{p.emoji}</span><div className="cart-detail"><b>{p.name}</b><strong>{money(p.price)}</strong><div className="qty"><button onClick={()=>changeQty(p.id,-1)}><Minus size={13}/></button>{p.qty}<button onClick={()=>changeQty(p.id,1)}><Plus size={13}/></button></div></div></div>)}</div><div className="cart-total"><span>Total estimé</span><b>{money(total)}</b></div><button className="checkout" onClick={()=>setCheckout(true)}>Passer la commande</button></>}{checkout&&<form className="checkout-form" onSubmit={submitOrder}><h3>Informations de livraison</h3>{["name","phone","address","email"].map((k)=><input key={k} required placeholder={{name:"Nom complet",phone:"Téléphone",address:"Adresse de livraison",email:"Adresse e-mail"}[k]} value={customer[k]} onChange={e=>setCustomer({...customer,[k]:e.target.value})}/>)}<button className="checkout">Confirmer la commande</button><small>Le paiement sera confirmé séparément avec le vendeur.</small></form>}</div></div>}
  </div>;
}
export default App;
